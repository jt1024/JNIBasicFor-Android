//
// Created by tao1024 on 2018/3/15.
//

#include <jni.h>
#include <string>

extern "C"
JNIEXPORT jstring

JNICALL
Java_com_tao_ndkfirstdemo_Java2CJNI_Java2C(JNIEnv *env, jobject instance) {

    return env->NewStringUTF("Hello world !");
}