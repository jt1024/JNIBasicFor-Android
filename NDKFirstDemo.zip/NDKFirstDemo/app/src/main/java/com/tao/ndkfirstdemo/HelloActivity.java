package com.tao.ndkfirstdemo;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

public class HelloActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_hello);
        Button btnJni = findViewById(R.id.btn_jni);
        btnJni.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String result = new Java2CJNI().Java2C();
                Toast.makeText(HelloActivity.this, result, Toast.LENGTH_LONG).show();
            }
        });
    }
}
