package com.tao.ndkfirstdemo;

/**
 * 作者： 麦典威
 * 修改时间：2018/3/15 0:02
 * 版权声明：www.ekwing.com
 * 功能： ${TODO}
 */


public class Java2CJNI {

    static {
        System.loadLibrary("hello_lib");
    }

    /**
     * 无参的 native 函数
     * @return
     */
    public native String Java2C();
}
