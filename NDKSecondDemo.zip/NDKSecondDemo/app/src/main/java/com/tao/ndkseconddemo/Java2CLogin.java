package com.tao.ndkseconddemo;

/**
 * 作者： 麦典威
 * 修改时间：2018/3/15 8:07
 * 版权声明：www.ekwing.com
 * 功能： ${TODO}
 */


public class Java2CLogin {
    static {
        System.loadLibrary("login_lib");
    }

    /**
     * 带参数的 native 函数
     *
     * @param username 用户名
     * @param password 密码
     * @param authcode 验证码
     * @return
     */
    public native String login(String username, String password, int authcode);
}
