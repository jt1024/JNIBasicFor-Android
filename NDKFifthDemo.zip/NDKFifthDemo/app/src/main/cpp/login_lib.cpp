#include <jni.h>
#include "string.h"

#include <android/log.h>

#define LOG_TAG    "jiat"
#define LOGD(...) __android_log_print(ANDROID_LOG_ERROR, LOG_TAG, __VA_ARGS__)

extern "C" JNIEXPORT jstring JNICALL
Java_com_tao_ndkfifthdemo_Java2CLogin_login(JNIEnv *env, jobject instance, jstring username, jstring password, jint authcode) {
    const char *resultMessage;
    if (authcode == 888) {
        const char *cStr;
        const char *pStr;
        jboolean isCopy;
        cStr = env->GetStringUTFChars(username, &isCopy);
        LOGD("cStr = %s", cStr);
        pStr = env->GetStringUTFChars(password, &isCopy);
        LOGD("pStr = %s", pStr);
        int reUsername = strcmp(cStr, "admin");
        LOGD("reUsername = %d", reUsername);
        int rePassword = strcmp(pStr, "1234");
        LOGD("rePassword = %d", rePassword);
        if (reUsername == 0 && rePassword == 0) {
            LOGD("success login !");
            resultMessage = "success login !";
        } else {
            LOGD("error username or error password");
            resultMessage = "error username or error password";
        }
    } else {
        LOGD("error authcode");
        resultMessage = "error authcode";
    }
    return env->NewStringUTF(resultMessage);
}

