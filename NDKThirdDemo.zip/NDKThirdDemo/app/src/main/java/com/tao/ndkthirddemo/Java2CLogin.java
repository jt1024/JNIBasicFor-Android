package com.tao.ndkthirddemo;

/**
 * 作者： 麦典威
 * 修改时间：2018/3/15 8:07
 * 版权声明：www.ekwing.com
 * 功能： ${TODO}
 */


public class Java2CLogin {

    private String codeError = "验证码错误！";
    private String usernameOrPasswordError = "用户名或密码错误！";
    private static String loginSuccess = "登录成功！";

    static {
        System.loadLibrary("login_lib");
    }

    /**
     * 带参数的 native 函数
     *
     * @param username 用户名
     * @param password 密码
     * @param authcode 验证码
     * @return
     */
    public native String login(String username, String password, int authcode);

}
