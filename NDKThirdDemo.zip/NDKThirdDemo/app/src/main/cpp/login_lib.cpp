#include <jni.h>
#include "string.h"

extern "C" JNIEXPORT jstring JNICALL
Java_com_tao_ndkthirddemo_Java2CLogin_login(JNIEnv *env, jobject instance, jstring username, jstring password, jint authcode) {
    jclass jclazz;

    //1.加载java类得到class对象
    jclazz = env->FindClass("com/tao/ndkthirddemo/Java2CLogin");

    //2.获取java类成员变量
    //2.1 获取java类成员变量ID
    jfieldID codeErrorID = env->GetFieldID(jclazz, "codeError", "Ljava/lang/String;");
    jfieldID usernameOrPasswordErrorID = env->GetFieldID(jclazz, "usernameOrPasswordError", "Ljava/lang/String;");
    jfieldID loginSuccessErrorID = env->GetStaticFieldID(jclazz, "loginSuccess", "Ljava/lang/String;");
    //2.2 通过成员变量ID获取java类成员变量
    jstring jcodeError = (jstring) env->GetObjectField(instance, codeErrorID);
    jstring jusernameOrPasswordError = (jstring) env->GetObjectField(instance, usernameOrPasswordErrorID);
    jstring jloginSuccess = (jstring) env->GetStaticObjectField(jclazz, loginSuccessErrorID);
    //return jloginSuccess;

    //3.验证
    if (authcode == 888) {
        const char *cStr;
        const char *pStr;
        jboolean isCopy;
        cStr = env->GetStringUTFChars(username, &isCopy);
        pStr = env->GetStringUTFChars(password, &isCopy);
        int reUsername = strcmp(cStr, "admin");
        int rePassword = strcmp(pStr, "1234");
        if (reUsername == 0 && rePassword == 0) {
            return jloginSuccess;
        } else {
            return jusernameOrPasswordError;
        }
    } else {
        return jcodeError;
    }
}

