#include <jni.h>
#include "string.h"

extern "C" JNIEXPORT void JNICALL
Java_com_tao_ndkfourthdemo_Java2CLogin_login(JNIEnv *env, jobject instance, jstring username, jstring password, jint authcode) {
    jclass jclazz;

    //1.加载java类得到class对象
    jclazz = env->FindClass("com/tao/ndkfourthdemo/Java2CLogin");
    //2.获取java类的函数
    //2.1 通过实例对象获取实例方法ID
    jmethodID showMessage = env->GetMethodID(jclazz, "showMessage", "(Ljava/lang/String;)V");

    if (authcode == 888) {
        const char *cStr;
        const char *pStr;
        jboolean isCopy;
        cStr = env->GetStringUTFChars(username, &isCopy);
        pStr = env->GetStringUTFChars(password, &isCopy);
        int reUsername = strcmp(cStr, "admin");
        int rePassword = strcmp(pStr, "1234");
        if (reUsername == 0 && rePassword == 0) {
            //2.2 通过方法ID调用实际的Java方法
            env->CallVoidMethod(instance, showMessage, env->NewStringUTF("登陆成功！"));
        } else {
            env->CallVoidMethod(instance, showMessage, env->NewStringUTF("用户名或密码错误！"));
        }
    } else {
        env->CallVoidMethod(instance, showMessage, env->NewStringUTF("验证码错误！"));
    }

}

extern "C" JNIEXPORT void JNICALL
Java_com_tao_ndkfourthdemo_Java2CLogin_jniNullFunc(JNIEnv *env, jobject instance) {
    jclass jclazz;
    jclazz = env->FindClass("com/tao/ndkfourthdemo/Java2CLogin");
    jmethodID nullFunc = env->GetMethodID(jclazz, "nullFunc", "()V");
    env->CallVoidMethod(instance, nullFunc);
}

extern "C" JNIEXPORT void JNICALL
Java_com_tao_ndkfourthdemo_Java2CLogin_jniIntFunc(JNIEnv *env, jobject instance) {
    jclass jclazz;
    jclazz = env->FindClass("com/tao/ndkfourthdemo/Java2CLogin");
    jmethodID intFunc = env->GetMethodID(jclazz, "intFunc", "(II)I");
    env->CallVoidMethod(instance, intFunc, 21, 12);
}

extern "C" JNIEXPORT void JNICALL
Java_com_tao_ndkfourthdemo_Java2CLogin_jniStringFunc(JNIEnv *env, jobject instance) {
    jclass jclazz;
    jclazz = env->FindClass("com/tao/ndkfourthdemo/Java2CLogin");
    jmethodID stringFunc = env->GetMethodID(jclazz, "stringFunc", "(Ljava/lang/String;)V");
    env->CallVoidMethod(instance, stringFunc, env->NewStringUTF("hello jni"));
}

extern "C" JNIEXPORT void JNICALL
Java_com_tao_ndkfourthdemo_Java2CLogin_jniStaticFunc(JNIEnv *env, jobject instance) {
    jclass jclazz;
    jclazz = env->FindClass("com/tao/ndkfourthdemo/Java2CLogin");
    jmethodID staticFunc = env->GetStaticMethodID(jclazz, "staticFunc", "()V");
    env->CallStaticVoidMethod(jclazz, staticFunc);
}

extern "C" JNIEXPORT void JNICALL
Java_com_tao_ndkfourthdemo_Java2CLogin_anotherFunc(JNIEnv *env, jobject instance) {
    jclass jclazz;
    jclazz = env->FindClass("com/tao/ndkfourthdemo/AnotherJava2CLogin");
    jmethodID showMessage = env->GetMethodID(jclazz, "showMessage", "()V");
    jobject dpobj = env->AllocObject(jclazz);//如果C调用的Java方法不在一个类中，则使用这行代码
    env->CallVoidMethod(dpobj, showMessage);
}

