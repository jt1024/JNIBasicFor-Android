package com.tao.ndkfourthdemo;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.util.Log;
import android.widget.Toast;

/**
 * 作者： 麦典威
 * 修改时间：2018/3/15 8:07
 * 版权声明：www.ekwing.com
 * 功能： ${TODO}
 */


public class Java2CLogin {
    private static final String TAG = "Java2CLogin";

    private Context mContext;

    static {
        System.loadLibrary("login_lib");
    }

    /**
     * 带参数的 native 函数
     *
     * @param username 用户名
     * @param password 密码
     * @param authcode 验证码
     * @return
     */
    public native void login(String username, String password, int authcode);

    public Java2CLogin(Context mContext) {
        this.mContext = mContext;
    }

    public void showMessage(final String msg) {

        Log.e(TAG, "jt——>C调用了java的 showMessage 函数——>" + msg);
        Handler handler = new Handler(Looper.getMainLooper());
        handler.post(new Runnable() {
            @Override
            public void run() {
                Toast.makeText(mContext, msg, Toast.LENGTH_LONG).show();
            }
        });
    }

    public native void jniNullFunc();

    public native void jniIntFunc();

    public native void jniStringFunc();

    public native void jniStaticFunc();

    public native void anotherFunc();


    //C调用java中的空方法
    public void nullFunc() {
        Log.e(TAG, "C调用java中的空方法");
    }

    //C调用java中的带两个int参数的方法
    public int intFunc(int x, int y) {
        Log.e(TAG, "C调用java中的带两个int参数的方法——>x + y=" + (x + y));
        return x + y;
    }

    //C调用java中参数为string的方法
    public void stringFunc(String s) {
        Log.e(TAG, "C调用java中参数为string的方法——>s=" + s);
    }

    //C调用java的静态方法
    public static void staticFunc() {
        Log.e(TAG, "C调用java的静态方法");
    }

}
