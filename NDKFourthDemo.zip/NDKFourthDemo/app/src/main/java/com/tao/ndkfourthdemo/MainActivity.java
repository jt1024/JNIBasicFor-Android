package com.tao.ndkfourthdemo;

import android.os.Bundle;
import android.support.v7.app.AppCompatActivity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class MainActivity extends AppCompatActivity {

    private static final String TAG = "MainActivity";
    private EditText edtUsername, edtPassword, edtAuthcode;
    private Button btnLogin, btn_jni1, btn_jni2, btn_jni3, btn_jni4, btn_jni5;
    private Java2CLogin java2CLogin;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        java2CLogin = new Java2CLogin(MainActivity.this);
        initView();
    }

    private void initView() {
        edtUsername = findViewById(R.id.edt_username);
        edtPassword = findViewById(R.id.edt_password);
        edtAuthcode = findViewById(R.id.edt_authcode);
        btnLogin = findViewById(R.id.btn_login);
        btn_jni1 = findViewById(R.id.btn_jni1);
        btn_jni2 = findViewById(R.id.btn_jni2);
        btn_jni3 = findViewById(R.id.btn_jni3);
        btn_jni4 = findViewById(R.id.btn_jni4);
        btn_jni5 = findViewById(R.id.btn_jni5);

        btnLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                String username = edtUsername.getText().toString().trim();
                String password = edtPassword.getText().toString().trim();
                String authcodeStr = edtAuthcode.getText().toString().trim();
                int authcode = Integer.parseInt(authcodeStr.equals("") ? "0" : authcodeStr);
                java2CLogin.login(username, password, authcode);
            }
        });

        btn_jni1.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                java2CLogin.nullFunc();
            }
        });

        btn_jni2.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                java2CLogin.jniIntFunc();
            }
        });

        btn_jni3.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                java2CLogin.jniStringFunc();
            }
        });

        btn_jni4.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                java2CLogin.staticFunc();
            }
        });

        btn_jni5.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                java2CLogin.anotherFunc();
            }
        });
    }
}

