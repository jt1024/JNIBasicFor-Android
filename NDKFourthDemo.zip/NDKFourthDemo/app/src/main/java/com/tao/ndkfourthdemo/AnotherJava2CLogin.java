package com.tao.ndkfourthdemo;

import android.util.Log;

/**
 * 作者： 麦典威
 * 修改时间：2018/3/22 10:21
 * 版权声明：www.ekwing.com
 * 功能： ${TODO}
 */


public class AnotherJava2CLogin {

    private static final String TAG = "AnotherJava2CLogin";

    public void showMessage() {
        Log.e(TAG, "jt——>native与java方法不在一个类时，C调用java的方法");
    }
}
